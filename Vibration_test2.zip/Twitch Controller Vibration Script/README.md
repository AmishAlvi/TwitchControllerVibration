# Streamlabs-Chatbot-Python-Boilerplate

Information on the Python Scripting Structure for the Streamlabs Chatbot can be located on github Wiki above.